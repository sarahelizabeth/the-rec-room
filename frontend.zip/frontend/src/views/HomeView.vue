<script setup>
</script>

<template>
  <div class="column">
    <h1 class="title is-2">Welcome</h1>
  </div>
</template>
